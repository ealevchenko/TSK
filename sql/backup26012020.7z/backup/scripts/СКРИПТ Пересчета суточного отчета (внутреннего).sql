USE [ASUTSK]
GO

delete from [ASUTSK].[dbo].[Daily_Accounting_Report]
delete from [ASUTSK].[dbo].[Daily_Accounting_Detali_Report]
delete from [ASUTSK].[dbo].[RemainsTanks]
delete from [ASUTSK].[dbo].[ReceivingTanks]
delete from [ASUTSK].[dbo].[DeliveryTanks]

go

exec [ASUTSK].[dbo].[ADD_DailyAccountingDetaliReport]
go
exec [ASUTSK].[dbo].[ADD_DailyAccountingReport]
go