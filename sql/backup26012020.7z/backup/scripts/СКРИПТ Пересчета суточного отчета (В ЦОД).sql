USE [ASUTSK]
GO

delete from [10.21.4.168].[KRR-PA-CNT-Oil].[dbo].[Daily_Accounting_Report_TSK]
delete from [10.21.4.168].[KRR-PA-CNT-Oil].[dbo].[Daily_Accounting_Detali_Report_TSK]
delete from [10.21.4.168].[KRR-PA-CNT-Oil].[dbo].[RemainsTanks_TSK]
delete from [10.21.4.168].[KRR-PA-CNT-Oil].[dbo].[ReceivingTanks_TSK]
delete from [10.21.4.168].[KRR-PA-CNT-Oil].[dbo].[DeliveryTanks_TSK]

go

exec [ASUTSK].[dbo].[ADD_DailyAccountingReport_DC]
go
